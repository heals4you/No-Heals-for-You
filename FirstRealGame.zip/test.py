import pygame

x = pygame.mouse.get_pos()
print(x)